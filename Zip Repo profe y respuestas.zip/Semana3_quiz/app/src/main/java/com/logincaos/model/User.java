package com.logincaos.model;

public class User {
    public String username;
    public String email;
    public String password;
}
